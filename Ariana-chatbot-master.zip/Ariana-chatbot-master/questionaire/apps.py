from django.apps import AppConfig


class QuestionaireConfig(AppConfig):
    name = 'questionaire'
