from django.contrib import admin
from . models import stock,billdetails

admin.site.register(stock)
admin.site.register(billdetails)