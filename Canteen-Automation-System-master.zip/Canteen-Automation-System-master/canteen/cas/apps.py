from django.apps import AppConfig


class CasConfig(AppConfig):
    name = 'cas'
