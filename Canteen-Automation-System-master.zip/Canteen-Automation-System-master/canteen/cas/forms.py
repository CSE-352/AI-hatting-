'''from django import forms
from alogin.models import stock
class StockForm(forms.ModelForm):
	class Meta:
		model=stock
		fields='__all__'
		
		'''