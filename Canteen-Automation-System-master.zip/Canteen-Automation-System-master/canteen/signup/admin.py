from django.contrib import admin
from . models import newuser

admin.site.register(newuser)