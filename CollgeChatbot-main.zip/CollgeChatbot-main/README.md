# CollgeChatbot
This project is to develop a college enquiry chatbot which answers any queries post by students like professor’s contact details, course related questions, location of university buildings etc.
It is a text-based conversation.
We have used Python as a backend language , with help of flask Freamework.
This system will be WEB application which could be added to college official website which provides to queries of student very well.
