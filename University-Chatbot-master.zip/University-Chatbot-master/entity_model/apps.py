from django.apps import AppConfig


class EntityModelConfig(AppConfig):
    name = 'entity_model'
