from django.apps import AppConfig


class IntentModelConfig(AppConfig):
    name = 'intent_model'
